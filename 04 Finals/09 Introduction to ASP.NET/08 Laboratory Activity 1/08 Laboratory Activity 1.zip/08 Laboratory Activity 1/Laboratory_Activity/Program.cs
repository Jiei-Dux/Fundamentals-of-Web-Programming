﻿namespace Laboratory_Activity
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, [Jay Doctor]!");
        }
    }
}