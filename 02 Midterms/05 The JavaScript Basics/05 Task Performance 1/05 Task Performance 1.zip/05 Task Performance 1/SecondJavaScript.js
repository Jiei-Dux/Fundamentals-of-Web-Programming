/* 
 * 
 * Javascript
 * 05 Task Performance 1 - SecondJavaScript.js
 * Fundamentals of Web Programming
 * 
 */

let Num = 0;

function secondJavaScript1() {

    for( Num; Num <= 30; Num++ ) {
        console.log(Num);
    }

}

function secondJavaScript2() {

    for( Num; Num <= 20; Num++ ) {
        console.log(Num * 2);
    }

}

function secondJavaScript3() {

    for( Num = 13; Num >= 4; Num-- ) {
        console.log(Num * 3);
    }

}